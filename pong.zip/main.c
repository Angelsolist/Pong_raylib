#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "pong.h"

int main(void)
{
    srand(time(NULL));

    Vector2 player1 = {10, ALTURA/2+ALTURARETANGULO/2};
    Vector2 player2 = {LARGURA-LARGURARETANGULO - 10,ALTURA/2+ALTURARETANGULO/2};
    Vector2 bola = {LARGURA/2,ALTURA/2};
    int bolasolta = 0, x, pontuacao1 = 0, pontuacao2 = 0, reinicia = 0;
    int direcao = rand() % 4 + 1;

    InitWindow(LARGURA, ALTURA, "Tentando pong");

    Music musica = inicializamusica();
    SetTargetFPS(FPS);

    while (!WindowShouldClose())
    {
        UpdateMusicStream(musica);
        movejogadores(&player1, &player2);

        reinicia = 0;

        if (IsKeyPressed(KEY_SPACE))
            bolasolta = 1;

        bola = movimentabola(&bola, direcao, bolasolta);            // ball movement
        direcao = mudadirecao(bola, direcao, &player1, &player2);   // new direction

        x = mudapontuacao(bola,direcao);                            // update points
        if (x == 1)
        {
            pontuacao1++;
            reinicia++;
        }
        if (x == 2)
        {
            pontuacao2++;
            reinicia++;
        }

        bolasolta = reinicio(bolasolta, &bola,reinicia);        // lateral wall collision

        checavencedor(pontuacao1,pontuacao2, &bola);

        // Draw

        BeginDrawing();

        DrawRectangle(player1.x, player1.y-ALTURARETANGULO, LARGURARETANGULO, ALTURARETANGULO, WHITE);      //draw players
        DrawRectangle(player2.x, player2.y-ALTURARETANGULO, LARGURARETANGULO, ALTURARETANGULO, WHITE);

        Desenhamapa(bolasolta);             //draw map

        DrawCircle(bola.x, bola.y, LARGURARETANGULO, YELLOW);       // draw ball

        DrawText((TextFormat("%d", pontuacao1)), LARGURA/2 - LARGURARETANGULO*4, LARGURARETANGULO, ALTURARETANGULO/1.5, YELLOW);    // draw points1
        DrawText((TextFormat("%d", pontuacao2)), LARGURA/2 + LARGURARETANGULO*2.3, LARGURARETANGULO, ALTURARETANGULO/1.5, YELLOW);

        EndDrawing();

    }
    CloseWindow();
    CloseAudioDevice();

    return 0;
}
