#include "pong.h"

void Desenhamapa(int bolasolta)
{
    int i;

    ClearBackground(BLACK);
    HideCursor();
    if (bolasolta == 0)
    {
        DrawText("Aperte espaco para\nsoltar a bola", LARGURA/4, ALTURARETANGULO, GROSSURA/2, YELLOW);
    }
    DrawFPS(LARGURA - GROSSURA*2, 2);


    for (i = 0; i <= ALTURA; i = i + GROSSURA)
    {
        DrawRectangle(LARGURA/2 - GROSSURA/13, i, GROSSURA/5, GROSSURA/2, WHITE);
    }
}

Music inicializamusica()
{
    InitAudioDevice();                                         // Initialize audio device and context
    Music musica = LoadMusicStream("mus.mp3");
    PlayMusicStream(musica);
    return musica;
}

void movejogadores (Vector2 *player1, Vector2 *player2)
{
    if (IsKeyDown(KEY_W)) player1->y -= 5.0f;
    if (IsKeyDown(KEY_S)) player1->y += 5.0f;
    if (IsKeyDown(KEY_UP)) player2->y -= 5.0f;                   // movimentacoes (W, S, SETA CIMA, SETA BAIXO)
    if (IsKeyDown(KEY_DOWN)) player2->y += 5.0f;

    if ((player1->y >ALTURA) && (IsKeyDown(KEY_S)))             // posicoes player 2 (limites)
        player1->y = ALTURA;
    if ((player1->y <ALTURARETANGULO) && (IsKeyDown(KEY_W)))
        player1->y = ALTURARETANGULO;
    if ((player2->y >ALTURA) && (IsKeyDown(KEY_DOWN)))           // posicoes player 1 (limites)
        player2->y = ALTURA;
    if ((player2->y <ALTURARETANGULO) && (IsKeyDown(KEY_UP)))
        player2->y = ALTURARETANGULO;


}


Vector2 movimentabola(Vector2 *bola, int direcao, int bolasolta)
{
    if (bolasolta == 1)
    {
        switch (direcao)
        {
        case 1:                      // superior direito
            bola->x = bola->x + VELOCIDADEBOLA;
            bola->y = bola->y - VELOCIDADEBOLA;
            break;
        case 2:                      // inferior direito
            bola->x = bola->x + VELOCIDADEBOLA;
            bola->y = bola->y + VELOCIDADEBOLA;
            break;
        case 3:                     // inferior esquerdo
            bola->x = bola->x - VELOCIDADEBOLA;
            bola->y = bola->y + VELOCIDADEBOLA;
            break;
        case 4:                      // superior esquerdo
            bola->x = bola->x - VELOCIDADEBOLA;
            bola->y = bola->y - VELOCIDADEBOLA;
            break;
        }
    }
    return *bola;
}

int mudadirecao(Vector2 bola, int direcao, Vector2 *player1, Vector2 *player2)
{
    Rectangle jogador1 = {player1->x + LARGURARETANGULO, player1->y - ALTURARETANGULO, LARGURARETANGULO, ALTURARETANGULO};
    Rectangle jogador2 = {player2->x - LARGURARETANGULO, player2->y - ALTURARETANGULO, LARGURARETANGULO, ALTURARETANGULO};

    if (direcao == 1)
    {
        if (bola.y < LARGURARETANGULO/2)
            direcao = 2;
        else if ((bola.x > LARGURA - LARGURARETANGULO/2) || (CheckCollisionCircleRec(bola, LARGURARETANGULO, jogador2)))
            direcao = 4;
    }
    else if (direcao == 2)
    {
        if (bola.y > ALTURA - LARGURARETANGULO/2)
            direcao = 1;
        else if ((bola.x > LARGURA - LARGURARETANGULO/2) || (CheckCollisionCircleRec(bola, LARGURARETANGULO, jogador2)))
            direcao = 3;
    }
    else if (direcao == 3)
    {
        if (bola.y > ALTURA - LARGURARETANGULO/2)
            direcao = 4;
        else if ((bola.x < LARGURARETANGULO/2) || (CheckCollisionCircleRec(bola, LARGURARETANGULO, jogador1)))
            direcao = 2;
    }
    else if (direcao == 4)
    {
        if (bola.y < LARGURARETANGULO/2)
            direcao = 3;
        else if ((bola.x < LARGURARETANGULO/2) || (CheckCollisionCircleRec(bola, LARGURARETANGULO, jogador1)))
            direcao = 1;
    }

    return direcao;
}

int mudapontuacao (Vector2 bola, int direcao)
{
    if (((direcao == 1)||(direcao == 2))&&(bola.x > LARGURA - LARGURARETANGULO))
    {
        return 1;
    }
    else if (((direcao == 3)||(direcao == 4))&&(bola.x < LARGURARETANGULO))
    {
        return 2;
    }
    return 0;
}

int reinicio (int bolasolta, Vector2 *bola, int reinicia)
{
    if ((reinicia == 1)&&(bolasolta=1))
    {
        bola->x = LARGURA/2;
        bola->y = ALTURA/2;
        return 0;
    }
}

void checavencedor (int pontuacao1, int pontuacao2, Vector2 *bola)
{
    char vitoria1[LARGURARETANGULO*2] = "Jogador 1 venceu!";
    char vitoria2[LARGURARETANGULO*2] = "Jogador 2 venceu!";
    if (pontuacao1 == 5)
    {
        bola->x = LARGURA/2;
        bola->y = ALTURA/2;
        DrawText(vitoria1, LARGURA/2 - ALTURARETANGULO*1.6, ALTURA/2, 30, MAGENTA);
    }
    else if (pontuacao2 == 5)
    {
        bola->x = LARGURA/2;
        bola->y = ALTURA/2;
        DrawText(vitoria2, LARGURA/2 - ALTURARETANGULO*1.6, ALTURA/2, 30, MAGENTA);
    }
}
