#define LARGURA 960
#define ALTURA 540
#define LARGURARETANGULO 15
#define ALTURARETANGULO 80
#define GROSSURA 40
#define FPS 60
#define VELOCIDADEBOLA 5
#include "raylib.h"


void Desenhamapa(int bolasolta);
Music inicializamusica();
Vector2 movimentabola(Vector2 *bola, int direcao, int bolasolta);
int mudadirecao(Vector2 bola, int direcao, Vector2 *player1, Vector2 *player2);
int mudapontuacao (Vector2 bola, int direcao);
int reinicio (int bolasolta, Vector2 *bola, int reinicia);
void movejogadores (Vector2 *player1, Vector2 *player2);
void checavencedor (int pontuacao1, int pontuacao2, Vector2 *bola);

